import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
from small_lstm import SmallLSTM
import os

def gen_series(n=2000, season=24):
    t = np.arange(n)
    data = 10 + 3*np.sin(2*np.pi*t/season) + 0.3*t/200 + np.random.randn(n)*0.5
    return data

def create_dataset(series, seq_len=24):
    X, y = [], []
    for i in range(len(series)-seq_len):
        X.append(series[i:i+seq_len])
        y.append(series[i+seq_len])
    X = np.array(X)[:, :, None]
    y = np.array(y)[:, None]
    return X, y

def train(save_path='models/lstm_v1.pt'):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    series = gen_series(2000)
    X, y = create_dataset(series)
    ds = TensorDataset(torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.float32))
    dl = DataLoader(ds, batch_size=64, shuffle=True)

    model = SmallLSTM(in_size=1, hidden=32)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = torch.nn.MSELoss()

    for epoch in range(12):
        total = 0
        for xb, yb in dl:
            pred = model(xb)
            loss = loss_fn(pred, yb)
            opt.zero_grad(); loss.backward(); opt.step()
            total += loss.item()
        print('epoch', epoch, 'loss', total/len(dl))

    torch.save({'model_state':model.state_dict(), 'meta':{'version':'v1'}}, save_path)
    print('saved to', save_path)

if __name__=='__main__':
    train()
