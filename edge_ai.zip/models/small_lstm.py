import torch
import torch.nn as nn

class SmallLSTM(nn.Module):
    def __init__(self, in_size=1, hidden=32, n_layers=1, out_size=1):
        super().__init__()
        self.lstm = nn.LSTM(in_size, hidden, n_layers, batch_first=True)
        self.fc = nn.Linear(hidden, out_size)

    def forward(self, x):
        o, _ = self.lstm(x)
        out = self.fc(o[:, -1, :])
        return out
