import requests, json
def send(payload):
    try:
        requests.post('http://127.0.0.1:5002/submit', json=payload, timeout=2)
    except Exception as e:
        print('telemetry error', e)
