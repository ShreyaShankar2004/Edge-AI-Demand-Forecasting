import sys, os, json, time, threading, argparse
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.small_lstm import SmallLSTM
import torch
from edge.utils.integrity import sha256_file
from edge.utils.downloader import download_file
import requests

parser = argparse.ArgumentParser()
parser.add_argument('--config', default='edge/config_store_001.json')
args = parser.parse_args()

with open(args.config) as f:
    cfg = json.load(f)

REGISTRY_LATEST = f"http://127.0.0.1:5001/latest/{cfg.get('group','production')}"
STORE_ID = cfg.get('store_id','store_001')
MODEL_DIR = os.path.join(os.path.dirname(__file__),'models')
os.makedirs(MODEL_DIR, exist_ok=True)

CURRENT = None
MODEL = None

def safe_load(path):
    ckpt = torch.load(path, map_location='cpu')
    if 'model_state' in ckpt:
        state = ckpt['model_state']
    else:
        state = ckpt
    m = SmallLSTM()
    m.load_state_dict(state)
    m.eval()
    return m

def apply_model(filename, expected_sha):
    global MODEL, CURRENT
    dst = os.path.join(MODEL_DIR, filename)
    download_url = f"http://127.0.0.1:5001/download/{filename}"
    print('[EDGE] Downloading', download_url)
    download_file(download_url, dst)
    got = sha256_file(dst)
    if got != expected_sha:
        print('[EDGE] SHA mismatch', got, '!=', expected_sha)
        os.remove(dst)
        return False
    prev = os.path.join(MODEL_DIR, 'previous_model.pt')
    cur = os.path.join(MODEL_DIR, 'current_model.pt')
    if os.path.exists(cur):
        if os.path.exists(prev):
            os.remove(prev)
        os.replace(cur, prev)
    os.replace(dst, cur)
    try:
        MODEL = safe_load(cur)
        CURRENT = filename
        print('[EDGE] Model applied and loaded', CURRENT)
        return True
    except Exception as e:
        print('[EDGE] Failed to load model', e)
        if os.path.exists(prev):
            os.replace(prev, cur)
            try:
                MODEL = safe_load(cur)
                CURRENT = os.path.basename(cur)
                print('[EDGE] Rolled back to previous model', CURRENT)
            except Exception as e2:
                print('[EDGE] Rollback also failed', e2)
        return False

def poll_registry():
    while True:
        try:
            print('[EDGE] Polling registry for latest model...')
            r = requests.get(REGISTRY_LATEST, timeout=5)
            if r.status_code==200:
                info = r.json()
                fname = info['filename']
                sha = info['sha256']
                if fname != CURRENT:
                    print('[EDGE] New model available', fname)
                    apply_model(fname, sha)
                else:
                    print('[EDGE] Up to date', CURRENT)
            else:
                print('[EDGE] Registry response', r.status_code, r.text)
        except Exception as e:
            print('[EDGE] Poll error', e)
        time.sleep(cfg.get('poll_interval', 15))

def run_inference_loop():
    import numpy as np
    while True:
        if MODEL is None:
            print('[EDGE] Model not loaded yet')
            time.sleep(3)
            continue
        seq = np.random.randn(24).tolist()
        import torch
        xb = torch.tensor(seq, dtype=torch.float32).reshape(1,24,1)
        out = MODEL(xb).item()
        print(f'[EDGE] Forecast sample: {out:.3f}')
        payload = {'store_id': STORE_ID, 'ts': __import__('datetime').datetime.utcnow().isoformat(), 'model_version': CURRENT, 'latency_ms': 12.3, 'forecast': out, 'cpu': 10.1, 'mem': 45.3}
        try:
            requests.post('http://127.0.0.1:5002/submit', json=payload, timeout=3)
        except:
            pass
        time.sleep(cfg.get('infer_interval', 10))

if __name__=='__main__':
    t = threading.Thread(target=poll_registry, daemon=True)
    t.start()
    run_inference_loop()
