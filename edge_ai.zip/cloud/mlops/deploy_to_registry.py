import argparse, json, requests
parser = argparse.ArgumentParser()
parser.add_argument('--package', required=True)
parser.add_argument('--registry', default='http://127.0.0.1:5001/register')
args = parser.parse_args()
pkg = json.load(open(args.package))
r = requests.post(args.registry, json={'version':pkg['version'], 'path':pkg['path'], 'groups': ','.join(pkg['groups'])})
print('Registry response', r.status_code, r.text)
