Edge Device README
------------------
- Configure store and group in config_store_XXX.json
- Run edge device: python edge/edge_device.py --config edge/config_store_001.json
- Optionally start HTTP API: python edge/edge_forecast_api.py
