import requests, os
def download_file(url, dst):
    r = requests.get(url, stream=True)
    r.raise_for_status()
    tmp = dst + '.tmp'
    with open(tmp, 'wb') as f:
        for chunk in r.iter_content(8192):
            if chunk:
                f.write(chunk)
    os.replace(tmp, dst)
    return dst
