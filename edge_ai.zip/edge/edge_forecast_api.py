from fastapi import FastAPI, HTTPException
import uvicorn
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from edge.edge_device import MODEL
from pydantic import BaseModel
app = FastAPI()
class Req(BaseModel):
    store_id: str
    product_id: str
    recent_series: list
@app.post('/forecast')
def forecast(req: Req):
    global MODEL
    import torch, numpy as np
    if MODEL is None:
        raise HTTPException(status_code=503, detail='model not loaded')
    x = np.array(req.recent_series[-24:])
    xb = torch.tensor(x[None,:,None], dtype=torch.float32)
    pred = MODEL(xb).detach().numpy().ravel()[0]
    return {'forecast': float(pred)}
if __name__=='__main__':
    uvicorn.run(app, port=8000)
