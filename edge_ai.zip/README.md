# Edge-AI Demand Forecasting — Production-ready Prototype (LSTM)

This repository is a complete prototype of an Edge-AI Demand Forecasting & MLOps platform.
It includes:
- Cloud model registry with SHA256 verification, canary/staged rollouts and rollback support.
- Edge device client that auto-pulls models, verifies integrity, supports atomic swap and rollback, and runs local inference via a lightweight LSTM.
- MLOps pipeline scripts to train, validate, package, and deploy models to the registry.
- Telemetry ingestion server and simple analytics API.
- Sensor simulator and telemetry sender for demoing multiple devices.

## Quickstart (minimal)
1. Create virtual environment and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate   # windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Start registry + telemetry + analytics (three terminals):
   ```bash
   python cloud/registry/registry_server.py
   python cloud/telemetry/telemetry_server.py
   python cloud/analytics/analytics_api.py
   ```
3. Train a model and package it for registry:
   ```bash
   python models/train.py
   python cloud/mlops/package_model.py --model models/lstm_v1.pt --version v1 --groups "A,B,production"
   python cloud/mlops/deploy_to_registry.py --package cloud/mlops/packages/lstm_v1.pkg.json
   ```
4. Start an edge device (example):
   ```bash
   python edge/edge_device.py --config edge/config_store_001.json
   ```
5. Use the sensor simulator to push forecasts + telemetry:
   ```bash
   python edge/sensor_simulator.py --edge-url http://localhost:8000/forecast
   ```

## Components overview
- `cloud/registry`: model registry service (stores metadata and model files)
- `cloud/telemetry`: collects telemetry and forecasts from edges (SQLite)
- `cloud/analytics`: simple analytics API to query telemetry and performance
- `cloud/mlops`: training/packaging/deploy scripts
- `edge`: edge client, model store, integrity verifier, telemetry sender, sensor simulator
- `models`: model definitions and training script (LSTM)
