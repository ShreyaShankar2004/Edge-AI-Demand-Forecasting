import time, requests, argparse, random, json
parser = argparse.ArgumentParser()
parser.add_argument('--edge-url', default='http://127.0.0.1:8000/forecast')
args = parser.parse_args()
while True:
    series = [10 + 3*(i%24)/24 + random.random()*0.2 for i in range(24)]
    try:
        r = requests.post(args.edge_url, json={'store_id':'store_001','product_id':'p1','recent_series':series}, timeout=3)
        print('sim sent', r.status_code)
    except Exception as e:
        print('sim error', e)
    time.sleep(5)
