from flask import Flask, request, jsonify, send_from_directory
import os, json, hashlib, time

app = Flask(__name__)
BASE = os.path.dirname(__file__)
STORE = os.path.join(BASE, 'model_store')
META = os.path.join(STORE, 'metadata.json')
os.makedirs(STORE, exist_ok=True)
if not os.path.exists(META):
    with open(META,'w') as f:
        json.dump({}, f)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    if not data:
        return jsonify({'error':'json required'}), 400
    version = data.get('version')
    local_path = data.get('path')  # path relative to repo for prototype
    groups = data.get('groups','production').split(',') if isinstance(data.get('groups','production'), str) else data.get('groups')
    if not version or not local_path:
        return jsonify({'error':'version and path required'}), 400
    # copy file to model_store with timestamped name
    src = os.path.abspath(local_path)
    if not os.path.exists(src):
        return jsonify({'error':'model file not found', 'path': src}), 400
    filename = f"{int(time.time())}_{os.path.basename(src)}"
    dst = os.path.join(STORE, filename)
    with open(src,'rb') as fr, open(dst,'wb') as fw:
        fw.write(fr.read())
    h = sha256_file(dst)
    with open(META,'r') as f:
        db = json.load(f)
    db[version] = {'filename': filename, 'sha256': h, 'groups': groups, 'timestamp': time.time()}
    with open(META,'w') as f:
        json.dump(db, f, indent=2)
    return jsonify({'status':'ok','version':version,'filename':filename,'sha256':h})

@app.route('/latest/<group>')
def latest(group):
    with open(META,'r') as f:
        db = json.load(f)
    if not db:
        return jsonify({'error':'no models'}), 404
    # find latest version that targets this group or 'production'
    items = [(v,m) for v,m in db.items() if group in m.get('groups',[]) or 'production' in m.get('groups',[])]
    if not items:
        return jsonify({'error':'no model for group'}), 404
    # pick newest by timestamp
    items.sort(key=lambda x: x[1].get('timestamp',0))
    ver, meta = items[-1]
    return jsonify({'version':ver, 'filename':meta['filename'], 'sha256':meta['sha256'], 'download':'/download/'+meta['filename']})

@app.route('/download/<path:filename>')
def download(filename):
    return send_from_directory(STORE, filename, as_attachment=True)

if __name__=='__main__':
    app.run(port=5001, debug=True)
