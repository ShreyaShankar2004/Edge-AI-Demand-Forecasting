import argparse, json, os, hashlib, time
parser = argparse.ArgumentParser()
parser.add_argument('--model', required=True)
parser.add_argument('--version', required=True)
parser.add_argument('--groups', default='production')
parser.add_argument('--outdir', default='cloud/mlops/packages')
args = parser.parse_args()
os.makedirs(args.outdir, exist_ok=True)
def sha256_file(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()
meta = {'version': args.version, 'path': os.path.abspath(args.model), 'sha256': sha256_file(args.model), 'groups': args.groups.split(',') if isinstance(args.groups,str) else args.groups, 'timestamp': time.time()}
fname = os.path.join(args.outdir, f"{args.version}.pkg.json")
with open(fname,'w') as f:
    json.dump(meta, f, indent=2)
print('Wrote package', fname)
