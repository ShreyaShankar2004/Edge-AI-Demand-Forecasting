from flask import Flask, request, jsonify
import sqlite3, os, time

BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, 'telemetry.sqlite')
app = Flask(__name__)

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS telemetry (id INTEGER PRIMARY KEY, store_id TEXT, ts TEXT, model_version TEXT, latency_ms REAL, forecast REAL, cpu REAL, mem REAL)''')
    conn.commit(); conn.close()
init_db()

@app.route('/submit', methods=['POST'])
def submit():
    p = request.get_json()
    if not p:
        return jsonify({'error':'json required'}),400
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO telemetry (store_id,ts,model_version,latency_ms,forecast,cpu,mem) VALUES (?,?,?,?,?,?,?)', (
        p.get('store_id'), p.get('ts'), p.get('model_version'), p.get('latency_ms'), p.get('forecast'), p.get('cpu'), p.get('mem')
    ))
    conn.commit(); conn.close()
    return jsonify({'status':'ok'})

@app.route('/query', methods=['GET'])
def query():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    rows = c.execute('SELECT store_id, ts, model_version, latency_ms, forecast, cpu, mem FROM telemetry ORDER BY ts DESC LIMIT 500').fetchall()
    conn.close()
    return jsonify({'rows': rows})

if __name__=='__main__':
    app.run(port=5002, debug=True)
