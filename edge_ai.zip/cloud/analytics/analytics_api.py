from flask import Flask, jsonify
import requests
app = Flask(__name__)
TELEMETRY = 'http://127.0.0.1:5002/query'

@app.route('/kpis')
def kpis():
    r = requests.get(TELEMETRY)
    rows = r.json().get('rows',[])
    out = {}
    for store,ts,ver,lat,fc,cpu,mem in rows:
        out.setdefault(store, {'count':0,'avg_latency':0.0})
        s = out[store]
        s['count'] += 1
        s['avg_latency'] += (lat or 0.0)
    for k in out:
        out[k]['avg_latency'] = out[k]['avg_latency']/out[k]['count'] if out[k]['count']>0 else None
    return jsonify(out)

if __name__=='__main__':
    app.run(port=5003, debug=True)
